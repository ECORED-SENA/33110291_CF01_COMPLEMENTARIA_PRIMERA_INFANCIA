function ExecuteScript(strId)
{
  switch (strId)
  {
      case "66UKnigH8hc":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

